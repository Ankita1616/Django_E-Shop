from django.shortcuts import render ,redirect, HttpResponseRedirect
from django.contrib.auth.hashers import check_password
from store.models.customer import Customer



from django.views import View
#login page in a class view
class Login(View): #view class a subclass create kiye
    return_url = None
    def get(self, request):
        Login.return_url = request.GET.get('return_url')
        return render(request, 'login.html')

    def post(self, request):
        Email = request.POST.get('email')
        Password = request.POST.get('password')
        customer = Customer.get_customer_by_Email(Email)
        if customer:
            flag = check_password(Password, customer.Password)  # password match krega
            if flag:
                request.session['customer'] = customer.id #saveing customer informatiom in session
                request.session['Email'] = customer.Email #if we the above only e will get a error of serriolisation mean
                  # we have to serial the coustomer details but if ew do id and email it will work properly
                #return redirect('homepage')
                if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)
                else:
                    Login.return_url = None
                    return redirect('homepage')
            else:
                error_message = ' Email or Password invalid !!'
        else:
            error_message = 'Email or Password invalid !!'
        print(Email, Password)
        return render(request, 'login.html', {'error': error_message})

def logout(request):
    request.session.clear()
    return redirect('login')