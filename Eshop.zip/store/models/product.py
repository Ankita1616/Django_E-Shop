from django.db import models #models can perfrom all the query of dbms
from .category import Category
class Product(models.Model): #sub class of models which is imported form django.db
    Name = models.CharField(max_length=50) #these value cant be null
    Price = models.IntegerField(default=0)
    #now we r adding product with category because we dont have to change both columns category and product
    #means we will have a refrence of category which have some id so name will be one side and
    # reference will be in product so that we dont have to change both of them and redadency also get removed
    #so we use forign key here
    category = models.ForeignKey(Category, on_delete= models.CASCADE,default = 1)
    Description = models.CharField(max_length=200, default='', null=True, blank=True)
    Features = models.CharField(max_length=200, default='')
    Details = models.CharField(max_length=200, default='')
    image = models.ImageField(upload_to= 'uploads/products/') #for imagefield we have to install pillow
#for getting a products in a index page we r calling a method and puting all the objects in it

    @staticmethod
    def get_products_by_id(ids):
        return Product.objects.filter(id__in =ids)#for cart fetching

    @staticmethod
    def get_all_products():
        return Product.objects.all()
 # we r doing the below because we want that by clicking that category we get only that product
    @staticmethod
    def get_all_products_by_categoryid(category_id):
        if category_id:
            return Product.objects.filter(category = category_id)
        else:
            return Product.get_all_products();

