#in this file whatever models r present in this models package it will migrate it and create a table
from .product import  Product #.product means current directory me jo python file hai
from .category import Category
from .customer import Customer
from .orders import Order