#we will chech here that in the card that perticular product is present or so for that we will use
#filter we will create a folder templatetags in which we we keep all our filters so cart is for our filter
#in this file we will create a function and  pass product and cart to this function will return us true or false
#the function will be in python file and we will call it in the index.html so this is the use of filter



from django import template

register = template.Library()

@register.filter(name ='currency')
def currency(number):
    return "₹ "+str(number)

@register.filter(name ='multiply')
def multiply(number,number1):
    return number * number1

