#we will chech here that in the card that perticular product is present or so for that we will use
#filter we will create a folder templatetags in which we we keep all our filters so cart is for our filter
#in this file we will create a function and  pass product and cart to this function will return us true or false
#the function will be in python file and we will call it in the index.html so this is the use of filter



from django import template

register = template.Library()

@register.filter(name = 'is_in_cart')
def is_in_cart(product , cart ):
    #for id in products:
        #print(id.id)
    #return True;
    keys = cart.keys()
    #checking product is in the cart or not
    for id in keys:
        if int(id) == product.id:
            return True
    return False;

#for add to cart showing quantity counting quantity
@register.filter(name = 'cart_quantity')
def cart_quantity(product , cart ):
    #for id in products:
        #print(id.id)
    #return True;
    keys = cart.keys()
    #checking product is in the cart or not
    for id in keys:
        if int(id) == product.id:
            return cart.get(id)
    return 0;

#for perticular product totals
@register.filter(name = 'price_total')
def price_total(product , cart ):
    return product.Price * cart_quantity(product, cart)

#for total price
@register.filter(name = 'total_cart_price')
def total_cart_price(products, cart):
    sum=0;
    for p in products:
        sum += price_total(p, cart)
    return sum

#<img src="{{product.image.url}}" class="card-img-top" alt="Card image cap">